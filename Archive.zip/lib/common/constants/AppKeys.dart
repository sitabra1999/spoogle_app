class AppKeys{
  AppKeys._();


  //Below 2 keys from OK Cabs Driver App
  static const String googleMapKeyOKCabsDriverApp = "AIzaSyARu4AffVt-BfEKC5WRxcQXg3OEjyeAL-w";
  static const String googleDirectionsKeyOKCabsDriverApp = "AIzaSyARu4AffVt-BfEKC5WRxcQXg3OEjyeAL-w";

  //Below 2 keys from TLT Driver
  static const String googleMapKeyTltDriverApp = "AIzaSyAJyzOhJBr-3I0aErGmue98rhhuYZTLR6s";

}