import 'package:flutter/material.dart';

class HomeCategoryModel {
  String title;
  String img;

  HomeCategoryModel({required this.title, required this.img});
}

