import 'package:flutter/material.dart';
import 'package:flutter_spoogle_app/common/constants/size_constants.dart';
import 'package:flutter_spoogle_app/common/constants/strings.dart';
import 'package:flutter_spoogle_app/common/extensions/CommonFun.dart';
import 'package:flutter_spoogle_app/presentation/libraries/FlutterSizer/flutter_sizer.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../themes/app_color.dart';
import '../../widgets/YtPlayerWidget.dart';



var videoList = [Strings.youTubeVideo1, Strings.youTubeVideo2, Strings.youTubeVideo3, Strings.youTubeVideo4];

class AlsoMayLikeNewsVideosWidget extends StatelessWidget {
  final Function onTap;
  const AlsoMayLikeNewsVideosWidget({Key? key,required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return ListView(
      scrollDirection: Axis.horizontal,
      children: List.generate(videoList.length, (index) {
        return Container(
          height: Sizes.dimen_20.h,
          width: getScreenWidth(context)/1.7,
          padding: const EdgeInsets.only(right: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              YtPlayerWidget(videoUrl: videoList[index]),
              const Padding(
                padding: EdgeInsets.only(top: 5),
                child: Text(
                  "Pakistan To Beat in the NZ World Cup?",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: AppColor.black),
                ),
              ),

              Container(
                height: 22,
                padding: const EdgeInsets.fromLTRB(0, 5, 4, 4,),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      "Soccer, General",
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.normal, color: Colors.black),
                    ),
                    Text.rich(
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: AppColor.black, fontSize: 10),
                      TextSpan(
                        children: [
                          WidgetSpan(child: Icon(Icons.thumb_up_outlined, size: 12, color: AppColor.black,)),
                          TextSpan(text: ' 10'),
                          TextSpan(text: '  '),
                          WidgetSpan(child: Icon(Icons.visibility_outlined, size: 12, color: AppColor.black,)),
                          TextSpan(text: ' 500  '),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

}