import 'dart:ffi';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spoogle_app/common/extensions/CommonFun.dart';
import 'package:flutter_spoogle_app/presentation/libraries/Languages/StringExtensions.dart';
import 'package:flutter_spoogle_app/presentation/libraries/videos/VideoThumbnailWidget.dart';
import 'package:flutter_spoogle_app/presentation/themes/app_color.dart';
import 'package:flutter_spoogle_app/presentation/widgets/AppbarIcBack.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../../common/constants/strings.dart';
import '../../../data/core/api_constants.dart';
import '../../../data/data_sources/api_functions.dart';
import '../../../data/models/MediaVideo/MediaVideoApiResModel.dart';
import '../../libraries/AppContents/NoDataWidget.dart';
import '../../libraries/AppContents/ProgressLibs/LoaderOverlay.dart';
import '../../libraries/AppContents/liquid_pull_to_refresh_and_internet_checker/PullToRefreshAndInternetCheckerWidget.dart';
import '../../libraries/Languages/TranslationConstants.dart';
import '../../widgets/NewsCategoryWidget.dart';
import '../../widgets/YtPlayerWidget.dart';
import '../NewsDetails/VideoDetails.dart';

class VideoGallery extends StatefulWidget {
  const VideoGallery({Key? key}) : super(key: key);

  @override
  State<VideoGallery> createState() => _VideoGalleryState();
}

class _VideoGalleryState extends State<VideoGallery> {
  late YoutubePlayerController controller;
  bool isApiDataAvailable = false;
  String mediaVideoId = '';
  MediaVideoApiResModel allVideos = MediaVideoApiResModel();
  bool isLastPageLoaded = false;
  int currentIndex = 0;
  final PagingController<int, GenericVideos> _pagingController = PagingController(firstPageKey: 1);
  final int pageSize = 10;
  int nextPage = 0;
  Future<bool> getMediaVideoData() async {
    try {
      await ApiFun.apiPostWithBody(ApiConstants.mediaVideo, {}).then((jsonData) {
        allVideos = MediaVideoApiResModel.fromJson(jsonData);
      });
    } catch (e) {
      debugPrint('---- Fetch all media videos api error: $e');
    }

    if (allVideos.status == 1) {
      isApiDataAvailable = true;
    }
    return isApiDataAvailable;
  }

  Future<void> _fetchVideoPage(String pageKey) async {
    if (!isLastPageLoaded) {
      final isLastPage = (allVideos.response.genericVideos.length) < pageSize;
      if (isLastPage) {
        _pagingController.appendLastPage(allVideos.response.genericVideos);
      } else {
        int nextPageKey = int.parse(pageKey) + 1;
        _pagingController.appendPage(allVideos.response.genericVideos, nextPageKey);
      }
      debugPrint('---- Page listening');
    }
  }

  @override
  void initState() {
    super.initState();
    addPageListener();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: appBarIcBack(context: context, text: "Video Gallery", bgColor: Colors.white, isCenterTitle: false),
        body: PullToRefreshAndInternetCheckerWidget(
          onReload: () {
            setState(() {
              isApiDataAvailable = true;
              getMediaVideoData();
            });
          },
          child: FutureBuilder(
              future: getMediaVideoData(),
              builder: (context, snapShot) {
            if (snapShot.hasData && snapShot.connectionState == ConnectionState.done) {
              if (isApiDataAvailable) {
                return PagedListView(
                    pagingController: _pagingController,
                    physics: const BouncingScrollPhysics(),
                    builderDelegate: PagedChildBuilderDelegate(
                        itemBuilder: (context, item, index) {
                          return InkWell(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  //YtPlayerWidget(videoUrl: allVideos.response.genericVideos[index].video),
                                  VideoThumbnailWidget(videoUrl:'https://www.youtube.com/watch?v=9nApkco-UUo', peerUserId: "", size: 30),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 12),
                                    child: Text(allVideos.response.genericVideos[index].title,
                                      style: const TextStyle(color: Colors.black, fontSize: 14),
                                    ),
                                  ),
                                  const Padding(
                                    padding: EdgeInsets.only(top: 8, bottom: 6),
                                    child: NewsCategoryWidget(height: 16),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 16),
                                    child: Text.rich(
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: AppColor.textColor, fontSize: 11),
                                      TextSpan(
                                        children: [
                                          WidgetSpan(
                                              child: Icon(
                                                Icons.thumb_up_outlined,
                                                size: 18,
                                                color: AppColor.textColor,
                                              )),
                                          TextSpan(text: allVideos.response.genericVideos[index].likes.toString()),
                                          TextSpan(text: '    '),
                                          WidgetSpan(
                                              child: Icon(
                                                Icons.visibility_outlined,
                                                size: 18,
                                                color: AppColor.textColor,
                                              )),
                                          TextSpan(text: allVideos.response.genericVideos[index].views.toString()),
                                          TextSpan(text: '    '),
                                          WidgetSpan(
                                              child: Icon(
                                                Icons.textsms_outlined,
                                                size: 16,
                                                color: AppColor.textColor,
                                              )),
                                          TextSpan(text: allVideos.response.genericVideos[index].comments.toString()),
                                          TextSpan(text: '    '),
                                          WidgetSpan(child: Icon(Icons.share, size: 15, color: AppColor.textColor)),
                                          //TextSpan(text: ' share  '),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            onTap: () {
                              openScreen(
                                  context, VideoDetails(url: allVideos.response.genericVideos[index].video, videoId: allVideos.response.genericVideos[index].videoid.toString()));
                            },
                          );
                        }));
              } else {
                return NoDataFound(
                  txt: TranslationConstants.noDataTryAgain.t(context),
                  onRefresh: () {
                    if (kDebugMode) {
                      print("here-2");
                    }
                    setState(() {
                      if (kDebugMode) {
                        print('here-3');
                      }isApiDataAvailable = false;
                    });
                  },
                );
              }
            } else {
              return showSimpleLoaderOverlay();
            }
          }),
        ));
  }

  String getYouTubeVideoId(String videoLink, int index) {
    return allVideos.response.genericVideos[index].video.split('youtu.be/')[1];
  }
  void addPageListener() {
    _pagingController.addPageRequestListener((pageKey) {
      _fetchVideoPage(pageKey.toString());
    });
  }
}
