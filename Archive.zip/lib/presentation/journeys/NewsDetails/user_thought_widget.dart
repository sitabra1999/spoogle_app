import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:flutter_spoogle_app/common/extensions/CommonFun.dart';
import 'package:flutter_spoogle_app/presentation/journeys/RefScreens/NewsComments.dart';
import 'package:flutter_spoogle_app/presentation/themes/app_color.dart';

import '../../../common/constants/strings.dart';
import '../../../data/core/api_constants.dart';
import '../../widgets/IcTxtXColumn.dart';

class UserThoughtWidget extends StatelessWidget {
  const UserThoughtWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.only(left: 24, right: 24),
      margin: const EdgeInsets.only(top: 24, bottom: 22),
      decoration: BoxDecoration(
        color: Colors.blue.shade50.withOpacity(0.35),
        borderRadius: const BorderRadius.all(Radius.circular(AppColor.appCornerRadius4)),
        //border: Border.all(color: Colors.grey.shade300, width: 0.9),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IcTxtXColumn(txt: "Like", ic: Icons.thumb_up, icColor: Colors.blue, onTap: () {}),
          IcTxtXColumn(txt: "View", ic: Icons.remove_red_eye, icColor: Colors.black54, onTap: () {}),
          IcTxtXColumn(
              txt: "Comment",
              ic: Icons.rate_review_outlined,
              icColor: Colors.black54,
              onTap: () {
                // openScreen(context, const NewsComments());
              },
          ),
          IcTxtXColumn(txt: "Share", ic: Icons.share, icColor: Colors.black54, onTap: () {
          }),
        ],
      ),
    );
  }
  void shareNews(String? title, String? text, String? link) async {
    String shareLink = '${Strings.websiteLink}${ApiConstants.newsDetails}/$link';
    await FlutterShare.share(title: title ?? 'Spoogle', text: text ?? 'Spoogle text', linkUrl: shareLink);
  }
}
