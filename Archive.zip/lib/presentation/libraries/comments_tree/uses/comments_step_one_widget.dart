import 'package:flutter/material.dart';
import 'package:flutter_spoogle_app/common/constants/strings.dart';
import 'package:flutter_spoogle_app/data/models/Stories/StoriesDetailsApiResModel.dart';
import 'package:flutter_spoogle_app/presentation/libraries/CachedNetworkImage/cached_net_img.dart';
import 'package:flutter_spoogle_app/presentation/libraries/comments_tree/comment_tree.dart';

import '../../../themes/app_color.dart';
import 'ChatInputField.dart';

class CommentsStepOneWidget extends StatelessWidget {
  final List<Comments>? comment;
  final String header;
  final Function() onTapOnReply;
  const CommentsStepOneWidget({Key? key, required this.header, required this.onTapOnReply, this.comment}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          header,
          style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 16,
        ),
        ListTile(
          isThreeLine: false,
          contentPadding: const EdgeInsets.only(left: 12, top: 0),
          leading: cachedNetImgWithRadius(Strings.imgUrlPersonSmileCall2, 35, 35, 25, BoxFit.cover),
          title: const Text(
            'Elina White',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColor.black),
          ),
          subtitle: const Text(
            "You always give good advice. What would you say to someone?",
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal, color: AppColor.black60),
          ),
          trailing: const Icon(Icons.reply,),
          onTap: (){
            onTapOnReply();
          },
        ),
        const Padding(
          padding: EdgeInsets.only(left: 65, bottom: 3, right: 40),
          child: Divider(
            color: Colors.black26,
          ),
        ),
        const Text.rich(
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Colors.black54, fontSize: 11),
          TextSpan(
            children: [
              WidgetSpan(
                  child: SizedBox(
                width: 65,
              )),
              WidgetSpan(
                child: Icon(
                  Icons.access_time,
                  size: 14,
                  color: Colors.black54,
                ),
              ),
              TextSpan(text: "  Posted 5 hr ago"),
              WidgetSpan(
                  child: SizedBox(
                width: 24,
              )),
              WidgetSpan(
                child: Icon(
                  Icons.insert_comment_outlined,
                  size: 14,
                  color: Colors.black54,
                ),
              ),
              TextSpan(text: "  20 comments"),
            ],
          ),
        ),
        ChatInputField(
          onSend: (String msg, String msgType) {},
        ),
      ],
    );
  }
}
