import 'package:flutter/material.dart';
import 'package:flutter_spoogle_app/common/constants/strings.dart';
import 'package:flutter_spoogle_app/presentation/libraries/CachedNetworkImage/cached_net_img.dart';

import '../../../themes/app_color.dart';

var dataList = [
  Strings.imgUrlTopNews1,
  Strings.imgUrlTopNews2,
  Strings.imgUrlTopNews3,
  Strings.imgUrlTopNews4,
  Strings.imgUrlTopNews5,
  Strings.imgUrlTopNews6
];

class CommentsListWidget extends StatelessWidget {
  final Function onTap;

  const CommentsListWidget({Key? key, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const NeverScrollableScrollPhysics(),
      scrollDirection: Axis.vertical,
      padding: const EdgeInsets.only(top: 12, left: 16),
      children: List.generate(dataList.length, (index) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              isThreeLine: false,
              contentPadding: const EdgeInsets.only(left: 12, top: 6),
              leading: cachedNetImgWithRadius(Strings.imgUrlPersonSmileCall2, 35, 35, 25, BoxFit.cover),
              title: const Text(
                'Elina White',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColor.black),
              ),
              subtitle: const Text(
                "You always give good advice.",
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal, color: AppColor.black60),
              ),
              onTap: () {},
            ),

            Text.rich(
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.black54, fontSize: 11),
              TextSpan(
                children: [
                  const WidgetSpan(
                    child: SizedBox(
                      width: 67,
                    ),
                  ),
                  const WidgetSpan(
                    child: Icon(
                      Icons.access_time,
                      size: 14,
                      color: Colors.black54,
                    ),
                  ),
                  const TextSpan(text: "  5m"),
                  const WidgetSpan(
                    child: SizedBox(
                      width: 24,
                    ),
                  ),
                  const WidgetSpan(
                    child: Icon(
                      Icons.insert_comment_outlined,
                      size: 14,
                      color: Colors.black54,
                    ),
                  ),
                  const TextSpan(text: "  5"),
                  const WidgetSpan(
                    child: SizedBox(
                      width: 24,
                    ),
                  ),
                  WidgetSpan(
                    child: InkWell(child:  const Text("  REPLY",
                      style: TextStyle(color: Colors.blue, fontSize: 11, fontWeight: FontWeight.bold),),
                      onTap:(){},
                    ),
                  ),

                ],
              ),
            ),
          ],
        );
      }),
    );
  }
}
