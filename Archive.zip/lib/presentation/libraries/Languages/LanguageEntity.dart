class LanguageEntity {
  final String code;
  final String value;

  const LanguageEntity({required this.code, required this.value});
}
