import 'LanguageEntity.dart';

class Languages {
  const Languages._();

  static const languages = [
    LanguageEntity(code: 'en', value: 'en'),
    LanguageEntity(code: 'hi', value: 'hi'),
  ];
}
