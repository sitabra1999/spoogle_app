/*

import 'package:flutter_spoogle_app/presentation/libraries/AppContents/Animations/animations.dart';
import 'package:flutter/material.dart';

Widget openContainerSimple({
  required Widget openBuilder,
  required Widget closedBuilder,
}){
  return OpenContainer<String>(
    closedColor: Colors.transparent,
    openColor: Colors.transparent,
    closedElevation: 0,
    tappable: false,
    transitionType : ContainerTransitionType.fadeThrough,
    openBuilder: (_, closeContainer) => openBuilder,
    closedBuilder: (_, openContainer) => AdListWidgets(onTap: openContainer,),
  );
}*/
