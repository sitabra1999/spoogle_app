package com.webtech.spoogle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
